#!/usr/bin/env bash
#
# capnhat.sh — Cap nhat gia pha len GitHub bang MOT lenh.
#
#   ./capnhat.sh ~/Downloads/file-moi-tu-myheritage.ged
#
# Script se:
#   1. Chay convert.py  -> sinh data.json + giapha.ged (ca hai DA LOC)
#   2. Kiem tra an toan -> chan neu du lieu bat thuong hoac lo ngay/thang
#   3. Cho xem thay doi -> hoi truoc khi push
#   4. git add / commit / push
#
# Neu bat ky buoc nao that bai, script DUNG NGAY. Khong push du lieu hong.

set -euo pipefail

DO='\033[0;31m'; XANH='\033[0;32m'; VANG='\033[1;33m'; XAM='\033[0;90m'; HET='\033[0m'

loi()  { echo -e "${DO}✗ $1${HET}" >&2; exit 1; }
ok()   { echo -e "${XANH}✓${HET} $1"; }
canh() { echo -e "${VANG}!${HET} $1"; }
muc()  { echo; echo -e "${XAM}── $1 ──${HET}"; }

cd "$(dirname "$0")"

# ─────────────────────────────────────────────────────────
# 0. Kiem tra dau vao
# ─────────────────────────────────────────────────────────
if [ $# -lt 1 ]; then
  echo "Cach dung:  ./capnhat.sh <file.ged tu MyHeritage>"
  echo
  echo "Vi du:      ./capnhat.sh ~/Downloads/pham-dinh.ged"
  exit 1
fi

NGUON="$1"
[ -f "$NGUON" ] || loi "Khong thay file: $NGUON"
[ -f convert.py ] || loi "Khong thay convert.py (chay script tu trong thu muc repo)"
command -v python3 >/dev/null || loi "Chua cai python3"
command -v git >/dev/null || loi "Chua cai git"

# Canh bao neu file nguon nam TRONG repo (de bi lo len GitHub)
if [ -z "$(realpath --relative-to=. "$NGUON" 2>/dev/null | grep '^\.\.')" ]; then
  canh "File goc dang nam trong thu muc repo."
  canh "Bao dam .gitignore co dong '*.ged' + '!giapha.ged' de no khong bi push."
fi

# ─────────────────────────────────────────────────────────
# 1. Sao luu ban cu (de quay ve neu co su co)
# ─────────────────────────────────────────────────────────
muc "1/4  Sao luu ban hien tai"
mkdir -p .saoluu
DAU=$(date +%Y%m%d-%H%M%S)
for f in data.json giapha.ged; do
  [ -f "$f" ] && cp "$f" ".saoluu/${f}.${DAU}"
done
ok "Da luu vao .saoluu/  (dau thoi gian ${DAU})"

# Doc so nguoi cua ban CU de doi chieu
CU=0
if [ -f data.json ]; then
  CU=$(python3 -c "import json;print(json.load(open('data.json'))['tong'])" 2>/dev/null || echo 0)
fi

# ─────────────────────────────────────────────────────────
# 2. Chuyen doi + loc
# ─────────────────────────────────────────────────────────
muc "2/4  Chuyen doi va loc du lieu"
python3 convert.py "$NGUON" data.json || loi "convert.py that bai — khong doi gi ca"

# ─────────────────────────────────────────────────────────
# 3. KIEM TRA AN TOAN — quan trong nhat
# ─────────────────────────────────────────────────────────
muc "3/4  Kiem tra an toan"

python3 kiemtra.py || loi "KIEM TRA THAT BAI — KHONG PUSH. Ban cu van con trong .saoluu/"

ok "Ca hai file sach"

# Doi chieu so nguoi — canh bao neu thay doi qua lon
MOI=$(python3 -c "import json;print(json.load(open('data.json'))['tong'])")
echo
echo -e "  So nguoi:  ${XAM}${CU}${HET}  →  ${XANH}${MOI}${HET}"

if [ "$CU" -gt 0 ]; then
  GIAM=$(( CU - MOI ))
  if [ "$GIAM" -gt 10 ]; then
    canh "Giam ${GIAM} nguoi so voi ban cu — bat thuong!"
    canh "Kiem tra ky truoc khi push. File cu van o .saoluu/"
    echo
    read -r -p "  Van tiep tuc? (go 'co' de tiep): " tra
    [ "$tra" = "co" ] || { echo "Da huy. Khong push gi ca."; exit 0; }
  fi
fi

# ─────────────────────────────────────────────────────────
# 4. Day len GitHub
# ─────────────────────────────────────────────────────────
muc "4/4  Day len GitHub"

git rev-parse --git-dir >/dev/null 2>&1 || loi "Thu muc nay khong phai repo git"

if git diff --quiet -- data.json giapha.ged 2>/dev/null; then
  ok "Du lieu khong doi — khong can push"
  exit 0
fi

echo "  Thay doi:"
git diff --stat -- data.json giapha.ged | sed 's/^/    /'
echo

read -r -p "  Day len GitHub? (Enter = co, 'k' = khong): " tra
if [ "$tra" = "k" ]; then
  echo "  Da huy. File moi van nam tren may, chua push."
  exit 0
fi

git add data.json giapha.ged
git commit -q -m "Cap nhat gia pha — ${MOI} nguoi ($(date +%d/%m/%Y))"
git push -q

echo
ok "Xong. Trang se cap nhat sau 1-2 phut."
echo -e "  ${XAM}https://hungps2.github.io/giapha/${HET}"
