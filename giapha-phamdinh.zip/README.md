# Gia phả họ Phạm Đình — trang tĩnh

## Nội dung
- `index.html` — toàn bộ trang (tìm kiếm + trang cá nhân + đường dẫn nhánh)
- `data.json` — dữ liệu đã xử lý (159 người, 55 gia đình, 9 đời)
- `giapha.ged` — **GEDCOM đã lọc**, dùng cho nút "Xem sơ đồ cây" (Topola). File này do
  `convert.py` sinh ra, KHÔNG phải bản gốc từ MyHeritage. Xem mục Riêng tư bên dưới.
- `convert.py` — bộ chuyển GEDCOM → JSON (lọc dữ liệu riêng tư)
- `kiemtra.py` — kiểm tra an toàn trước khi push (dùng chung cho cả hai script)
- `capnhat.bat` — **kéo thả file .ged vào là chạy** (lọc dữ liệu, kiểm tra an toàn)

## Đưa lên GitHub Pages
1. Tạo repo mới trên GitHub (ví dụ `giapha`).
2. Đẩy 3 file: `index.html`, `data.json`, `giapha.ged`.
3. Vào **Settings → Pages** → Source: `Deploy from a branch` → chọn nhánh `main`, thư mục `/ (root)` → Save.
4. Vài phút sau trang chạy ở `https://<tên-bạn>.github.io/giapha/`.
5. Trỏ `gpphamdinh.balienket.com` sang đó (CNAME trên Cloudflare) thay cho redirect MyHeritage.

## Nút "Xem sơ đồ cây"

Mở Topola Viewer với chính file `giapha.ged` của bạn. URL có tham số `&handleCors=false`
— **bắt buộc phải có**.

Mặc định Topola định tuyến file qua một CORS proxy công cộng, và proxy đó đang chết
→ báo lỗi "Failed to fetch". Tham số này bảo Topola gọi thẳng file. GitHub Pages tự
gửi header CORS nên chạy được.

Nếu sau này muốn hết lệ thuộc vào `pewu.github.io`, có thể tự host Topola trong repo:
tải https://github.com/PeWu/topola-viewer/archive/refs/heads/gh-pages.zip, giải nén vào
thư mục `topola/`, rồi sửa link trong `index.html` trỏ vào đó. Cùng tên miền → CORS
biến mất hoàn toàn.

## Cập nhật dữ liệu

### 1. Xuất GEDCOM từ MyHeritage

Family tree → Export to GEDCOM. Tải file về máy.

### 2. Lọc dữ liệu

**Kéo thả file `.ged` vào `capnhat.bat`.**

Script sinh ra **hai** file đã lọc:
- `data.json` — cho trang chính
- `giapha.ged` — cho nút "Xem sơ đồ cây"

Nếu bước kiểm tra báo `[X]` thay vì `[OK]` → **dừng lại, đừng upload**. File có vấn đề.

### 3. Upload lên GitHub

Vào repo `giapha` trên github.com → **Add file → Upload files** → kéo **cả hai** file
`data.json` và `giapha.ged` vào → Commit.

Trang cập nhật sau 1–2 phút.

---

## ⚠ Chỉ upload HAI file đó

**KHÔNG BAO GIỜ upload file `.ged` gốc từ MyHeritage.**

Bản gốc chứa:
- Ngày/tháng sinh đầy đủ của 109 người còn sống
- Email, địa chỉ
- Link ảnh MyHeritage

Chỉ `data.json` và `giapha.ged` do `capnhat.bat` sinh ra mới sạch. Nếu lỡ upload nhầm
file gốc, xoá nó khỏi repo ngay — nhưng nhớ rằng nội dung vẫn nằm trong lịch sử git,
nên tốt nhất là đừng để xảy ra.

Cách chắc ăn: **giữ file gốc ở thư mục khác**, ngoài thư mục repo.

---

### Làm bằng tay (nếu muốn)

```
python convert.py file-moi.ged data.json
python kiemtra.py
```

Lệnh đầu sinh cả hai file. Lệnh sau kiểm tra an toàn.

## `.gitignore` — lớp bảo vệ khỏi sai sót

Repo có sẵn file `.gitignore` với nội dung:

```
*.ged
!giapha.ged
.saoluu/
```

Nghĩa là: kể cả bạn lỡ copy file GEDCOM gốc từ MyHeritage vào thư mục repo, `git` cũng
sẽ **không** đẩy nó lên. Chỉ `giapha.ged` (bản đã lọc) được phép qua.

## RIÊNG TƯ — điều quan trọng nhất

**Người còn sống chỉ hiện NĂM sinh. Ngày và tháng bị cắt ngay từ lúc xuất.**

Cắt lúc xuất, không phải lúc hiển thị. Nghĩa là ngày/tháng sinh của 112 người còn sống
**không tồn tại trong `data.json`**. Ai mở thẳng file JSON, xem mã nguồn trang, hay tải
file về cũng không lấy được — vì dữ liệu đó chưa bao giờ rời khỏi máy bạn.

Đây là cách phân quyền duy nhất có thật trên trang tĩnh. Mọi cách khác (ẩn bằng CSS,
lọc bằng JavaScript, đặt mật khẩu trong mã) chỉ là màn che: dữ liệu vẫn đã tải về
máy người xem rồi.

Người đã mất giữ nguyên ngày tháng đầy đủ — cần cho giỗ chạp.

## Ba trạng thái, không phải hai

Trước đây trang suy: *không có ngày mất → còn sống*. Sai với cụ thủy tổ cách đây 15 đời —
cụ không có ngày mất, nhưng chắc chắn đã khuất.

Nay có ba trạng thái:

| | Điều kiện | Hiển thị |
|---|---|---|
| **Đã mất** | Có ngày/năm mất, **hoặc** đời ≤ 11 | Ngày giỗ, hoặc *"Đã mất — không rõ ngày"* |
| **Chưa rõ** | Sinh trước 1920, không có ngày mất | *"Chưa rõ — gia phả không ghi ngày mất"* |
| **Còn sống** | Còn lại | Còn sống |

Hai mốc này nằm ở đầu `convert.py`, sửa được:

```python
DOI_CHAC_MAT = 11    # doi <= 11: chac chan da khuat
NAM_NGUONG   = 1920  # sinh truoc 1920 ma khong co ngay mat -> chua ro
```

**Điều KHÔNG suy diễn:** *không có năm sinh* **không** dẫn đến *chưa rõ*. Có 33 người ở đời
13–15 chưa nhập năm sinh nhưng đang sống — đánh dấu họ "chưa rõ" là sai. Thiếu dữ liệu
không phải bằng chứng.

**Người "chưa rõ" được bảo vệ như người còn sống** — chỉ hiện năm sinh, cắt ngày tháng.
Nghi ngờ thì che, không phơi bày.

## Ngày giỗ không có năm — dạng riêng của gia phả Việt

Nhiều cụ tổ **chỉ còn ngày giỗ, mất năm**: năm thất lạc qua nhiều đời, nhưng ngày giỗ
thì con cháu vẫn nhớ — vì mỗi năm vẫn cúng. Ngày giỗ mới là thứ quan trọng, không phải năm.

Chuẩn GEDCOM không lo dạng này, nhưng `convert.py` xử lý được:

| Trong GEDCOM | Trang hiện |
|---|---|
| `16 APR 1995` | Ngày giỗ: **16/4/1995** |
| `23/02` | Ngày giỗ: **23/2** — *chưa rõ năm mất* |
| `1949` | Năm mất: **1949** |
| `APR 1995` | **tháng 4/1995** |

Hiện có 2 cụ ở dạng này: VIII. Phạm Quang Thực (23/2) và IX. Phạm Đình Bính (14/1).

Nhập trong MyHeritage: gõ thẳng `23/02` vào ô ngày mất, để trống năm.

## Cảnh báo dữ liệu

Mỗi lần chạy, `convert.py` báo các năm sinh/mất vô lý (dưới 1500 hoặc trên 2030).
Ví dụ hiện có: `XI.7.PHẠM ĐÌNH THẠC  sinh="892"` — thiếu một chữ số, chắc là 1892.

Script **chỉ cảnh báo, không tự sửa** — đoán ý định của người nhập là sai. Sửa trong
MyHeritage rồi xuất lại.

### Cả HAI file đều đã lọc

`convert.py` sinh ra hai file, và cả hai đều sạch:

| | `data.json` | `giapha.ged` |
|---|---|---|
| Dùng cho | trang chính | nút "Xem sơ đồ cây" (Topola) |
| Ngày/tháng sinh người còn sống | đã cắt | đã cắt |
| Cờ `DEAT Y` giả | đã bỏ | đã bỏ |
| Email, địa chỉ | không có | không có |
| Link ảnh MyHeritage | không có | không có |

**KHÔNG bao giờ đẩy file GEDCOM gốc từ MyHeritage lên GitHub.** Bản gốc chứa đầy đủ
ngày/tháng sinh của 112 người còn sống, email, và địa chỉ. Chỉ đẩy `giapha.ged` do
`convert.py` sinh ra.

## Bốn việc đã xử lý trong lúc chuyển đổi
1. **Cờ mất**: bạn tick "đã mất" cho cả 159 người để MyHeritage đừng ẩn người sống.
   Trên trang này không còn cơ chế ẩn đó, nên bộ chuyển đọc lại đúng: chỉ coi là đã mất
   khi có ngày mất thật → 47 đã mất, 112 còn sống.
2. **Riêng tư**: 34 người còn sống có ngày/tháng đầy đủ → cắt còn năm (xem mục trên).
3. **Đời của dâu/rể**: các bà dâu không có cha mẹ trong cây nên dễ bị xếp nhầm vào đời 1.
   Bộ chuyển tách huyết thống (137) và dâu/rể (22); dâu/rể lấy đời theo chồng/vợ.
4. **Ngày tháng**: `16 APR 1995` → `16/4/1995`.

## Về cách nhập tên
Bạn điền tên đầy đủ vào trường tên, để trống trường họ — đúng, vì GEDCOM là chuẩn
phương Tây (họ đứng sau). Bộ chuyển giữ nguyên tên đầy đủ.

Có vài bản ghi lẻ nhập theo kiểu cũ (`THỊ CÁT /NGUYỄN/`); bộ chuyển tự ghép lại thành
`NGUYỄN THỊ CÁT` cho đúng thứ tự Việt. Nếu muốn nhất quán, sửa mấy bản ghi đó trong
MyHeritage cho khớp phần còn lại.

## Ảnh
46 ảnh trong GEDCOM chỉ là **đường dẫn tới máy chủ MyHeritage**, có chữ ký hết hạn —
không tải về được từ file này. Muốn có ảnh: tải riêng từ MyHeritage, đặt vào thư mục
`anh/`, rồi bổ sung tên file vào `data.json`. Chưa làm ở bản này.
